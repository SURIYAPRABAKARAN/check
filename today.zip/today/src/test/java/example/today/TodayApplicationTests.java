package example.today;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodayApplicationTests {

	@Test
	void contextLoads() {
	}

}
