package example.today;

import org.springframework.stereotype.Component;

@Component
public class BeanUserToday {
	private String userId;
	private String userName;
	private String userDept;
	BeanUserToday(){}
	

	public BeanUserToday(String userId, String userName, String userDept) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userDept = userDept;
	}
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserDept() {
		return userDept;
	}

	public void setUserDept(String userDept) {
		this.userDept = userDept;
	}

	@Override
	public String toString() {
		return "BeanUserToday [userId=" + userId + ", userName=" + userName + ", userDept=" + userDept + "]";
	}
}
