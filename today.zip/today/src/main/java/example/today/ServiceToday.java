package example.today;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;

@Component
public class ServiceToday {
	@Autowired
	 static ArrayList<BeanUserToday> UserListObj = new ArrayList<BeanUserToday>();
	
	static {
		UserListObj.add(new BeanUserToday("001","Suriya","BSC-IT"));
		UserListObj.add(new BeanUserToday("002","prakash","ECE"));	
		UserListObj.add(new BeanUserToday("003","Ram","ECE"));	
		UserListObj.add(new BeanUserToday("004","Gowtham","BE-CS"));	
		UserListObj.add(new BeanUserToday("005","Meenakshi","BE-medical"));	
		UserListObj.add(new BeanUserToday("006","Hameed","BE-IT"));	
		UserListObj.add(new BeanUserToday("007","Riyazz","MI"));	
	}
	public ArrayList<BeanUserToday> findAllUsers() {
		return UserListObj;
	}
	public BeanUserToday findOneUser(String userId) {
		for(BeanUserToday foreach : UserListObj)
		{
			if(foreach.getUserId().equalsIgnoreCase(userId) )
			{
				return foreach;
			}
		}
		return null;
	}
	public BeanUserToday deleteUser(String userId)
	{
		for(BeanUserToday foreach : UserListObj)
		{
			if(foreach.getUserId().equalsIgnoreCase(userId) )
			{
				UserListObj.remove(foreach);
				return foreach;
			}
		}
		return null;
	}
	@Autowired
	public BeanUserToday postNewuser(BeanUserToday but)
	{
			UserListObj.add(but);
			return but;
	}	
}