package example.today;

@SuppressWarnings("serial")
public class UsernotFoundException extends Exception {

	public UsernotFoundException(String string)
	{
		super(string);
	}
}
